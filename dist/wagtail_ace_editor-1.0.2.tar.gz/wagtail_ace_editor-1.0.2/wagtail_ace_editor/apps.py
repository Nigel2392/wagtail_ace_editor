from django.apps import AppConfig


class WagtailAceEditorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wagtail_ace_editor'
